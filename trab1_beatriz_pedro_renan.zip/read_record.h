#ifndef READ_RECORD_H
#define READ_RECORD_H
#include <stdio.h>

short leia_registro(FILE *arq, char *str, int size); //Utilizada para ler os registros do livro.txt -> leitura primária para jogar em .dat

#endif
