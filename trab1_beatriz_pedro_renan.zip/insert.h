#ifndef INSERT_H
#define INSERT_H

void inserir(char* registro, short* tam_reg);

#endif