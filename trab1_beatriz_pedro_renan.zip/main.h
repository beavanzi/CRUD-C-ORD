#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>

#define TAM_MAX_REG 256
#define DELIM_STR "|"
#define BUSCA 98
#define INSERCAO 105
#define REMOCAO 114

//GLOBAIS
FILE *arquivo_dat;

#endif