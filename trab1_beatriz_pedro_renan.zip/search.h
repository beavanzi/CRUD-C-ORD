#ifndef SEARCH_H
#define SEARCH_H

int busca(int chave, int *posicao_de_seek, short *tam_reg, int isRemove);

#endif