#include <string.h>

#include "main.h"

void remocao(int posicao_de_seek, int *LEDHead) {
    char buffer[5], buffer_reg[TAM_MAX_REG], LEDHEAD_string[5];
    char asterisco = '*';

    fseek(arquivo_dat, (posicao_de_seek + 2), SEEK_SET);
    fwrite(&asterisco, sizeof(char), 1, arquivo_dat);
    fwrite(LEDHead, sizeof(int), 1, arquivo_dat);
    *LEDHead = posicao_de_seek;
    rewind(arquivo_dat);
    fwrite(LEDHead, sizeof(int), 1, arquivo_dat);  //no cabecalho
}