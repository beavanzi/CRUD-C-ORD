#ifndef REMOVE_H
#define REMOVE_H

void remocao(int posicao_de_seek, int *LEDHead);

#endif